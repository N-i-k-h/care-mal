import React from 'react';
import UserRouter from './router/userrouter'; // Adjust the import path as necessary
import './App.css'; // Import your CSS file for styling
function App() {
  return (
    <div className="App">
      <UserRouter />
    </div>
  );
}

export default App;
