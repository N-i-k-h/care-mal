import React from 'react';

function DoctorHome() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100">
      <div className="container mx-auto p-4">
        <h1 className="text-3xl font-bold text-green-600 mb-4">Welcome to Doctor's Dashboard</h1>
        <p className="text-gray-600">This is the home page for doctors. Here you can manage your appointments, view patient records, and more.</p>
        {/* Add more components and features specific to the doctor's dashboard */}
      </div>
    </div>
  );
}

export default DoctorHome;
